abstract class Lap1{
    public abstract void piill(int inp);
}
