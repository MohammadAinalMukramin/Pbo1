public class Lap2 extends Lapangan{
    @Override
    public int getNolap() {
        return super.getNolap();
    }
    @Override
    public String getJenlap() {
        return super.getJenlap();
    }
}
