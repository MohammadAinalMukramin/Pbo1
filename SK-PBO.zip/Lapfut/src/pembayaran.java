public interface pembayaran{
    public void penyewa(int pem);
}
